-- FIGHT 2 FIT GYM member app schema
-- Run in Supabase SQL Editor for your own project.
-- Do not expose a service_role key in the browser or APK.

create extension if not exists pgcrypto;

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  phone text,
  package_name text,
  membership_start date,
  membership_end date,
  admission_fee_paid boolean not null default false,
  goal text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount numeric(10,2) not null check (amount >= 0),
  description text not null default 'Membership payment',
  payment_type text not null default 'membership',
  status text not null default 'recorded' check (status in ('recorded','paid','pending','failed','refunded')),
  payment_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.progress_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  weight_kg numeric(6,2) check (weight_kg > 0 and weight_kg < 500),
  height_cm numeric(6,2) check (height_cm > 0 and height_cm < 300),
  logged_on date not null default current_date,
  notes text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.workout_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  plan_data jsonb not null default '{}'::jsonb,
  assigned_by text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.diet_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  plan_data jsonb not null default '{}'::jsonb,
  assigned_by text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  checked_in_at timestamptz not null default now(),
  checkin_method text not null default 'staff',
  verified boolean not null default false
);

alter table public.members enable row level security;
alter table public.payments enable row level security;
alter table public.progress_logs enable row level security;
alter table public.workout_plans enable row level security;
alter table public.diet_plans enable row level security;
alter table public.attendance_logs enable row level security;

-- Members can read/update only their own profile. Admin-side profile creation
-- should be done via a trusted server/admin workflow, not a public browser key.
drop policy if exists "members read own" on public.members;
create policy "members read own" on public.members for select to authenticated using (auth.uid() = user_id);
drop policy if exists "members update own basic profile" on public.members;
create policy "members update own basic profile" on public.members for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "payments read own" on public.payments;
create policy "payments read own" on public.payments for select to authenticated using (auth.uid() = user_id);
drop policy if exists "progress read own" on public.progress_logs;
create policy "progress read own" on public.progress_logs for select to authenticated using (auth.uid() = user_id);
drop policy if exists "progress insert own" on public.progress_logs;
create policy "progress insert own" on public.progress_logs for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "progress update own" on public.progress_logs;
create policy "progress update own" on public.progress_logs for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "progress delete own" on public.progress_logs;
create policy "progress delete own" on public.progress_logs for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "workout plans read own" on public.workout_plans;
create policy "workout plans read own" on public.workout_plans for select to authenticated using (auth.uid() = user_id);
drop policy if exists "diet plans read own" on public.diet_plans;
create policy "diet plans read own" on public.diet_plans for select to authenticated using (auth.uid() = user_id);
drop policy if exists "attendance read own" on public.attendance_logs;
create policy "attendance read own" on public.attendance_logs for select to authenticated using (auth.uid() = user_id);

-- Important: members cannot insert/update payments or attendance through client UI.
-- A trusted admin dashboard or server function should record those events.
