# Deployment and Website Connection Checklist

## Website
- [ ] Decide exact public URL (e.g. members.your-domain.com).
- [ ] Confirm hosting provider supports static Vite builds and HTTPS.
- [ ] Add Supabase URL redirect allow-list.
- [ ] Configure SPA fallback.
- [ ] Set Vite `base` if hosting under a path such as `/members/`.
- [ ] Add privacy policy and terms pages before public launch.

## Data / security
- [ ] Run `supabase/schema.sql` on your own project.
- [ ] Never use service-role key in browser/mobile app.
- [ ] Confirm RLS policies with at least two separate test members.
- [ ] Member cannot change package price, payment status, membership end date, attendance or admission fee status.
- [ ] Admin-side data entry is done through a trusted server/admin workflow.

## Android
- [ ] Set final app ID before first release.
- [ ] Add Android platform with Capacitor.
- [ ] Build and install debug APK.
- [ ] Test auth redirects, back button, keyboard and slow internet.
- [ ] Sign release build and store signing keys securely.
