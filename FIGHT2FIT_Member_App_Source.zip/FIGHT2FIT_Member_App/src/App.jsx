import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity, ArrowDownRight, ArrowRight, Bell, CalendarDays, Check, ChevronRight,
  CircleUserRound, ClipboardList, Clock3, CreditCard, Dumbbell, Flame, Gauge,
  Home, LogOut, Menu, QrCode, Settings, ShieldCheck, Sparkles, Target, TrendingUp,
  Utensils, Weight, X
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { isSupabaseConfigured, supabase } from './supabase.js';

const gymName = import.meta.env.VITE_GYM_NAME || 'FIGHT 2 FIT GYM';
const gymAddress = import.meta.env.VITE_GYM_ADDRESS || 'Officer Campus, Sirsi Road, Vaishali Nagar, Jaipur, Rajasthan';
const gymPhone = import.meta.env.VITE_GYM_PHONE || '';
const gymInstagram = import.meta.env.VITE_GYM_INSTAGRAM || 'https://instagram.com/fight2fitgym';
const gymWebsite = import.meta.env.VITE_GYM_WEBSITE || '';

const packages = [
  { name: '1 Month', price: 2000, duration: 1 },
  { name: '2 Months', price: 3500, duration: 2 },
  { name: '3 Months', price: 4500, duration: 3 },
  { name: '6 Months', price: 8000, duration: 6 },
  { name: '12 Months', price: 12000, duration: 12 }
];
const demoMember = {
  full_name: 'Demo Member', email: 'member@example.com', phone: '',
  package_name: '3 Months', membership_start: new Date().toISOString().slice(0,10),
  membership_end: new Date(Date.now() + 73 * 86400000).toISOString().slice(0,10),
  admission_fee_paid: false, goal: 'Muscle Building'
};
const sampleWorkouts = [
  { day: 'MON', title: 'Chest + Triceps', detail: 'Bench press · Incline dumbbell press · Cable fly · Triceps pushdown', tag: 'Strength' },
  { day: 'TUE', title: 'Back + Biceps', detail: 'Lat pulldown · Seated row · Dumbbell curl · Hammer curl', tag: 'Hypertrophy' },
  { day: 'WED', title: 'Legs + Core', detail: 'Squat · Leg press · Romanian deadlift · Plank', tag: 'Strength' },
  { day: 'THU', title: 'Shoulders + Abs', detail: 'Shoulder press · Lateral raise · Face pull · Cable crunch', tag: 'Control' },
  { day: 'FRI', title: 'Upper Body', detail: 'Chest-supported row · Incline press · Lateral raise · Arms', tag: 'Volume' },
  { day: 'SAT', title: 'Conditioning', detail: 'Bike intervals · Step-ups · Mobility · Stretching', tag: 'Fitness' }
];
const sampleDiet = [
  ['Breakfast', 'Oats / eggs / paneer', 'Choose portions from your trainer-approved plan'],
  ['Mid-morning', 'Fruit + water', 'Adjust to your individual plan'],
  ['Lunch', 'Roti/rice + dal + protein + vegetables', 'Portions should match your goal'],
  ['Pre-workout', 'Light snack + water', 'Avoid trying supplements without guidance'],
  ['Dinner', 'Protein source + vegetables + carbs as prescribed', 'Follow your assigned plan']
];

function dateOnly(value) {
  if (!value) return null;
  const d = new Date(`${value}T00:00:00`);
  return Number.isNaN(d.getTime()) ? null : d;
}
function daysBetween(from, to) { return Math.ceil((to.getTime() - from.getTime()) / 86400000); }
function statusFor(end) {
  const d = dateOnly(end);
  if (!d) return { label: 'Awaiting setup', className: 'neutral', days: null };
  const days = daysBetween(new Date(new Date().toDateString()), d);
  if (days < 0) return { label: 'Expired', className: 'expired', days };
  if (days <= 7) return { label: 'Expiring soon', className: 'soon', days };
  return { label: 'Active', className: 'active', days };
}
function money(n) { return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(n || 0)); }
function formatDate(d) { const parsed = dateOnly(d); return parsed ? parsed.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : 'Not set'; }

const navItems = [
  ['home', 'Overview', Home], ['membership', 'Membership', CreditCard], ['workout', 'Workout plan', Dumbbell],
  ['diet', 'Diet plan', Utensils], ['progress', 'Progress', TrendingUp], ['attendance', 'Attendance & QR', QrCode],
  ['payments', 'Payments', ClipboardList], ['profile', 'My profile', CircleUserRound]
];

export default function App() {
  const [page, setPage] = useState('home');
  const [showSplash, setShowSplash] = useState(true);
  const [member, setMember] = useState(demoMember);
  const [session, setSession] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [weight, setWeight] = useState('80');
  const [height, setHeight] = useState('175');
  const [measurements, setMeasurements] = useState([]);
  const [history, setHistory] = useState([]);
  const [showRenew, setShowRenew] = useState(false);

  useEffect(() => {
    const splashTimer = setTimeout(() => setShowSplash(false), 650);
    return () => clearTimeout(splashTimer);
  }, []);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) loadMember(data.session.user);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user) loadMember(nextSession.user);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadMember(user) {
    if (!supabase || !user) return;
    const { data, error } = await supabase.from('members').select('*').eq('user_id', user.id).maybeSingle();
    if (error) { setNotice('Profile load nahi hua. Supabase schema aur access rules check karein.'); return; }
    if (data) setMember({ ...demoMember, ...data, email: user.email || data.email });
    else setMember({ ...demoMember, full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'Member', email: user.email });
    const { data: paymentRows } = await supabase.from('payments').select('*').order('created_at', { ascending: false }).limit(20);
    setHistory(paymentRows || []);
    const { data: progressRows } = await supabase.from('progress_logs').select('*').order('logged_on', { ascending: false }).limit(20);
    setMeasurements(progressRows || []);
  }

  async function submitAuth(e) {
    e.preventDefault(); setNotice(''); setBusy(true);
    try {
      if (!isSupabaseConfigured) {
        setNotice('Demo mode: connect your own Supabase project in .env before real login. No account was created.');
        return;
      }
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({ email: authEmail, password: authPassword, options: { data: { full_name: authName } } });
        if (error) throw error;
        setNotice('Signup request sent. Verify your email if email confirmation is enabled, then log in.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
        if (error) throw error;
        setNotice('Login request successful.');
      }
    } catch (err) { setNotice(err.message || 'Login failed. Please try again.'); }
    finally { setBusy(false); }
  }

  async function signOut() {
    if (supabase && session) await supabase.auth.signOut();
    setSession(null); setMember(demoMember); setPage('home'); setNotice('Signed out.');
  }

  async function saveProgress(e) {
    e.preventDefault();
    const item = { weight_kg: Number(weight), height_cm: Number(height), logged_on: new Date().toISOString().slice(0,10), notes: '' };
    if (supabase && session) {
      const { error } = await supabase.from('progress_logs').insert({ ...item, user_id: session.user.id });
      if (error) { setNotice('Progress save nahi hua: ' + error.message); return; }
      const { data } = await supabase.from('progress_logs').select('*').order('logged_on', { ascending: false }).limit(20);
      setMeasurements(data || []);
    } else setMeasurements(prev => [item, ...prev]);
    setNotice('Progress entry saved.');
  }

  const status = statusFor(member.membership_end);
  const firstName = (member.full_name || 'Member').trim().split(/\s+/)[0];
  const bmi = useMemo(() => {
    const h = Number(height) / 100, w = Number(weight);
    return h > 0 && w > 0 ? (w / (h*h)).toFixed(1) : '—';
  }, [weight, height]);

  function go(p) { setPage(p); setMobileMenu(false); setNotice(''); }
  function Header() {
    return <header className="topbar">
      <button className="icon-btn mobile-toggle" aria-label="Open menu" onClick={() => setMobileMenu(!mobileMenu)}><Menu size={20}/></button>
      <div className="brand-mark"><span className="brand-symbol">F2F</span><div><b>FIGHT <i>2</i> FIT</b><small>GYM MEMBER CLUB</small></div></div>
      <div className="top-actions"><span className="connection"><span className={isSupabaseConfigured ? 'dot green' : 'dot amber'}></span>{isSupabaseConfigured ? 'Cloud ready' : 'Preview mode'}</span><button className="icon-btn" aria-label="Notifications" onClick={() => setNotice('Expiry reminders are a planned feature. Configure Supabase and notification delivery to enable real alerts.')}><Bell size={18}/></button><button className="avatar" onClick={() => go('profile')}>{firstName.slice(0,1).toUpperCase()}</button></div>
    </header>;
  }
  function Sidebar() {
    return <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
      <div className="side-label">MEMBER SPACE</div>
      {navItems.map(([id, label, Icon]) => <button key={id} className={`nav-link ${page===id?'selected':''}`} onClick={() => go(id)}><Icon size={18}/><span>{label}</span>{page===id && <ChevronRight size={15} className="nav-end"/>}</button>)}
      <div className="side-bottom"><div className="coach-card"><div className="coach-icon"><Flame size={19}/></div><b>Stay consistent.</b><p>Small steps. Strong results.</p><div className="coach-line"><span></span></div></div><button className="nav-link" onClick={signOut}><LogOut size={18}/><span>Sign out</span></button></div>
    </aside>;
  }
  function PageTitle({eyebrow,title,sub,action}) { return <div className="page-title"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{sub && <p>{sub}</p>}</div>{action}</div>; }
  function Notice() { return notice ? <div className="notice" role="status"><span>{notice}</span><button className="plain-icon" onClick={() => setNotice('')} aria-label="Dismiss"><X size={16}/></button></div> : null; }
  function HomePage() {
    return <>
      <PageTitle eyebrow="YOUR FITNESS JOURNEY" title={`Welcome back, ${firstName}`} sub="One session at a time. Keep building your strongest self." action={<button className="btn btn-primary" onClick={() => go('workout')}><Dumbbell size={17}/> View workout <ArrowRight size={16}/></button>}/>
      <div className="hero-banner"><div className="hero-copy"><div className="hero-pill"><Sparkles size={13}/> YOUR GOALS. YOUR GRIND.</div><h2>STRONGER<br/><span>EVERY DAY.</span></h2><p>Consistency beats perfection. Show up, put in the work, and let progress follow.</p><button className="btn btn-light" onClick={() => go('progress')}>Track your progress <ArrowRight size={16}/></button></div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="hero-figure"><Dumbbell size={92} strokeWidth={1.2}/></div><div className="hero-stat"><Flame size={16}/><div><b>ONE MORE REP</b><small>Make it count</small></div></div></div></div>
      <div className="section-heading"><div><h2>Your membership</h2><p>Quick view of your current plan</p></div><button className="text-btn" onClick={() => go('membership')}>View details <ArrowRight size={15}/></button></div>
      <div className="stats-grid">
        <div className="stat-card membership-stat"><div className="stat-top"><span>MEMBERSHIP STATUS</span><ShieldCheck size={18}/></div><div className={`status-badge ${status.className}`}><span className="status-dot"></span>{status.label}</div><h3>{member.package_name || 'Package not assigned'}</h3><p>Expires {formatDate(member.membership_end)}</p></div>
        <div className="stat-card"><div className="stat-top"><span>DAYS REMAINING</span><CalendarDays size={18}/></div><div className="big-stat">{status.days === null ? '—' : Math.max(status.days,0)}<small> days</small></div><div className="mini-progress"><span style={{width: `${Math.min(100, Math.max(0, (status.days || 0)/90*100))}%`}}></span></div><p>Renew on time to keep your routine going.</p></div>
        <div className="stat-card"><div className="stat-top"><span>YOUR FITNESS GOAL</span><Target size={18}/></div><div className="goal-chip"><Activity size={16}/>{member.goal || 'Goal not set'}</div><p>Stay aligned with your coach-approved plan.</p><button className="small-link" onClick={() => go('profile')}>Manage profile <ArrowRight size={14}/></button></div>
      </div>
      <div className="two-col"><section className="panel"><div className="panel-head"><div><h3>This week's training</h3><p>Keep your plan consistent</p></div><button className="plain-icon" onClick={() => go('workout')} aria-label="View workouts"><ArrowRight size={18}/></button></div><div className="workout-list">{sampleWorkouts.slice(0,3).map(w=><div className="workout-row" key={w.day}><div className="day-tile">{w.day}</div><div className="workout-info"><b>{w.title}</b><small>{w.tag}</small></div><ChevronRight size={17}/></div>)}</div><button className="btn btn-outline full" onClick={() => go('workout')}>Open workout plan</button></section><section className="panel nutrition-panel"><div className="panel-head"><div><h3>Nutrition focus</h3><p>Build good habits outside the gym</p></div><div className="panel-icon"><Utensils size={19}/></div></div><div className="nutrition-highlight"><div className="nutrition-symbol"><Utensils size={23}/></div><div><b>Fuel your training</b><p>Follow your assigned diet plan and hydration guidance.</p></div></div><div className="nutrition-foot"><span><Check size={15}/> Consistent meals</span><span><Check size={15}/> Hydration</span></div><button className="btn btn-outline full" onClick={() => go('diet')}>View diet plan</button></section></div>
      <div className="bottom-note"><ShieldCheck size={17}/><span>Your membership information is personal. Keep your login details private.</span></div>
    </>;
  }
  function MembershipPage() {
    return <><PageTitle eyebrow="PLAN & BENEFITS" title="My membership" sub="Your plan, dates and renewal options." action={<button className="btn btn-primary" onClick={() => setShowRenew(true)}>Explore packages <ArrowRight size={16}/></button>}/>
      <div className="membership-card"><div><div className="hero-pill"><ShieldCheck size={13}/> MEMBERSHIP OVERVIEW</div><h2>{member.package_name || 'Package not assigned'}</h2><div className={`status-badge ${status.className}`}><span className="status-dot"></span>{status.label}</div></div><div className="membership-ring"><span>{status.days === null ? '—' : Math.max(0,status.days)}</span><small>DAYS LEFT</small></div><div className="membership-dates"><div><small>START DATE</small><b>{formatDate(member.membership_start)}</b></div><div><small>EXPIRY DATE</small><b>{formatDate(member.membership_end)}</b></div><div><small>ADMISSION FEE</small><b>{member.admission_fee_paid ? 'Paid' : '₹200 one-time'}</b></div></div></div>
      <div className="section-heading"><div><h2>Available packages</h2><p>Admission fee of ₹200 is one-time, charged at admission if not already paid.</p></div></div>
      <div className="package-grid">{packages.map((p,i)=><div className={`package-card ${member.package_name===p.name?'current':''}`} key={p.name}>{i===2 && <div className="popular-label">POPULAR</div>}<div className="package-duration">{p.name}</div><div className="package-price">{money(p.price)}</div><div className="package-meta">{p.duration} {p.duration===1?'month':'months'} access</div><div className="package-includes"><span><Check size={14}/> Member app access</span><span><Check size={14}/> Membership status</span><span><Check size={14}/> Workout & diet plan*</span></div><button className={member.package_name===p.name?'btn btn-outline full':'btn btn-primary full'} onClick={() => setShowRenew(true)}>{member.package_name===p.name?'Current plan':'Ask to renew'}</button></div>)}</div>
      <p className="disclaimer">*Workout and diet plans depend on what the gym assigns to your member account. Selecting a package here does not process payment or activate a membership.</p>
      {showRenew && <div className="modal-backdrop" onClick={() => setShowRenew(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={() => setShowRenew(false)}><X size={18}/></button><div className="modal-icon"><CreditCard size={24}/></div><h2>Renewal request</h2><p>Choose your package and contact the gym to confirm availability and payment. This app does not collect or process payments yet.</p><div className="renew-options">{packages.map(p=><button key={p.name} onClick={() => {setNotice(`Selected ${p.name} (${money(p.price)}). Contact the gym to confirm renewal. One-time admission fee ₹200 applies only if not previously paid.`);setShowRenew(false)}}><span>{p.name}</span><b>{money(p.price)}</b><ChevronRight size={16}/></button>)}</div><p className="fee-note">One-time admission fee: ₹200 (if not already paid)</p></div></div>}
    </>;
  }
  function WorkoutPage() {
    return <><PageTitle eyebrow="TRAIN WITH PURPOSE" title="Workout plan" sub="A sample weekly split. Follow your trainer's assigned plan for your personal program."/><div className="callout"><Dumbbell size={20}/><div><b>Train smart. Recover well.</b><p>Warm up before lifting, use safe technique and ask your trainer to adjust exercises to your level.</p></div></div><div className="plan-list">{sampleWorkouts.map((w,i)=><div className="plan-card" key={w.day}><div className="plan-day">{w.day}<span>0{i+1}</span></div><div className="plan-content"><div className="plan-tag">{w.tag}</div><h3>{w.title}</h3><p>{w.detail}</p><small>Sample only · confirm your personalised sets and reps with your trainer</small></div><div className="plan-symbol"><Dumbbell size={22}/></div></div>)}</div></>;
  }
  function DietPage() {
    return <><PageTitle eyebrow="NUTRITION & RECOVERY" title="Diet plan" sub="General meal structure for preview only. Your coach should assign your actual quantities."/><div className="callout orange"><Utensils size={20}/><div><b>Your diet should fit your goal.</b><p>This sample is not a prescribed nutrition plan. Ask your trainer for your exact foods, portions and any allergy-related changes.</p></div></div><div className="diet-list">{sampleDiet.map((d,i)=><div className="diet-row" key={d[0]}><div className="meal-num">0{i+1}</div><div className="meal-main"><small>{d[0]}</small><b>{d[1]}</b><p>{d[2]}</p></div><div className="meal-icon"><Utensils size={19}/></div></div>)}</div></>;
  }
  function ProgressPage() {
    return <><PageTitle eyebrow="MEASURE WHAT MATTERS" title="My progress" sub="Log your measurements and watch your consistency build."/><div className="stats-grid progress-stats"><div className="stat-card"><div className="stat-top"><span>CURRENT WEIGHT</span><Weight size={18}/></div><div className="big-stat">{weight}<small> kg</small></div><p>Update your latest measurement below.</p></div><div className="stat-card"><div className="stat-top"><span>HEIGHT</span><Gauge size={18}/></div><div className="big-stat">{height}<small> cm</small></div><p>Used for an approximate BMI calculation.</p></div><div className="stat-card"><div className="stat-top"><span>ESTIMATED BMI</span><Activity size={18}/></div><div className="big-stat">{bmi}</div><p>BMI is a rough screening measure, not a diagnosis.</p></div></div><div className="two-col"><section className="panel"><div className="panel-head"><div><h3>Add measurement</h3><p>Keep your records up to date</p></div></div><form className="progress-form" onSubmit={saveProgress}><label>Weight (kg)<input type="number" min="1" max="400" step="0.1" value={weight} onChange={e=>setWeight(e.target.value)} required/></label><label>Height (cm)<input type="number" min="50" max="250" step="0.1" value={height} onChange={e=>setHeight(e.target.value)} required/></label><button className="btn btn-primary full" type="submit">Save progress <Check size={16}/></button></form></section><section className="panel"><div className="panel-head"><div><h3>Recent logs</h3><p>Latest measurement entries</p></div></div>{measurements.length ? <div className="history-list">{measurements.map((m,i)=><div className="history-row" key={m.id||i}><div className="history-icon"><TrendingUp size={17}/></div><div><b>{m.weight_kg} kg</b><small>{formatDate(m.logged_on)}</small></div><span>{m.height_cm} cm</span></div>)}</div>:<div className="empty-state"><TrendingUp size={26}/><b>No saved measurements yet</b><p>Add your first progress entry to start tracking.</p></div>}</section></div></>;
  }
  function AttendancePage() {
    const qrValue = session?.user?.id || member.email || 'F2F-DEMO-MEMBER';
    return <><PageTitle eyebrow="CHECK IN & SHOW UP" title="Attendance & QR pass" sub="Show your member pass to gym staff. The demo QR is not a live attendance credential."/><div className="two-col qr-layout"><section className="panel qr-panel"><div className="qr-frame"><QRCodeSVG value={`FIGHT2FIT:${qrValue}`} size={190} level="M" includeMargin/></div><h3>{member.full_name || 'Member'}</h3><p>{member.package_name || 'Membership not assigned'}</p><div className={`status-badge ${status.className}`}><span className="status-dot"></span>{status.label}</div><div className="qr-id">MEMBER ID · {String(qrValue).slice(0,14).toUpperCase()}</div><p className="disclaimer">Staff scanning system and server-side validation are not connected yet.</p></section><section className="panel"><div className="panel-head"><div><h3>Attendance history</h3><p>Your recent check-ins</p></div><CalendarDays size={19}/></div><div className="empty-state"><Clock3 size={27}/><b>No attendance records available</b><p>Once the gym connects a verified check-in system, attendance will appear here.</p></div></section></div></>;
  }
  function PaymentsPage() {
    return <><PageTitle eyebrow="PAYMENTS & RECEIPTS" title="Payment history" sub="Review payments recorded against your member account."/><div className="callout"><CreditCard size={20}/><div><b>Transparent membership pricing</b><p>₹200 one-time admission fee applies at admission if not already paid. Online payment is not enabled in this prototype.</p></div></div><section className="panel table-panel"><div className="panel-head"><div><h3>Recent payments</h3><p>Payments appear after the gym records them securely.</p></div></div>{history.length ? <div className="payment-list">{history.map((p,i)=><div className="payment-row" key={p.id||i}><div className="history-icon"><CreditCard size={17}/></div><div><b>{p.description || p.payment_type || 'Membership payment'}</b><small>{formatDate(p.created_at?.slice(0,10) || p.payment_date)}</small></div><strong>{money(p.amount)}</strong><span className={`status-badge ${p.status==='paid'?'active':'neutral'}`}>{p.status || 'Recorded'}</span></div>)}</div>:<div className="empty-state"><CreditCard size={27}/><b>No payment history yet</b><p>Your actual payments will appear once your gym account is linked to the database.</p></div>}</section></>;
  }
  function ProfilePage() {
    return <><PageTitle eyebrow="YOUR ACCOUNT" title="My profile" sub="Your personal details and gym contact information."/><div className="two-col"><section className="panel"><div className="profile-header"><div className="profile-avatar">{firstName.slice(0,1).toUpperCase()}</div><div><h3>{member.full_name || 'Member'}</h3><p>{member.email || 'Member email not linked'}</p><div className={`status-badge ${status.className}`}><span className="status-dot"></span>{status.label}</div></div></div><div className="detail-list"><div><span>Phone</span><b>{member.phone || 'Not added'}</b></div><div><span>Fitness goal</span><b>{member.goal || 'Not set'}</b></div><div><span>Membership</span><b>{member.package_name || 'Not assigned'}</b></div><div><span>Admission fee</span><b>{member.admission_fee_paid ? 'Paid' : '₹200 due if not previously paid'}</b></div></div><button className="btn btn-outline full" onClick={() => setNotice('Profile edits should be enabled through a verified member profile workflow after database setup.')}>Request profile update</button><button className="btn btn-quiet full" onClick={signOut}><LogOut size={16}/> Sign out</button></section><section className="panel contact-panel"><div className="panel-icon large"><Flame size={24}/></div><h3>{gymName}</h3><p className="contact-sub">Your training. Your community. Your progress.</p><div className="contact-detail"><Home size={17}/><span>{gymAddress}</span></div>{gymPhone && <div className="contact-detail"><Activity size={17}/><span>{gymPhone}</span></div>}<div className="contact-links"><a href={gymInstagram} target="_blank" rel="noreferrer">Instagram <ArrowRight size={14}/></a>{gymWebsite && <a href={gymWebsite} target="_blank" rel="noreferrer">Gym website <ArrowRight size={14}/></a>}</div><div className="bottom-note"><ShieldCheck size={16}/><span>Never share your password or OTP with anyone.</span></div></section></div></>;
  }
  const content = {home:<HomePage/>,membership:<MembershipPage/>,workout:<WorkoutPage/>,diet:<DietPage/>,progress:<ProgressPage/>,attendance:<AttendancePage/>,payments:<PaymentsPage/>,profile:<ProfilePage/>}[page] || <HomePage/>;

  return <div className="app-shell">
    <div className="splash-accent"></div>
    <Header/>
    <div className="layout"><Sidebar/><main className="main-content"><Notice/>{!isSupabaseConfigured && <div className="preview-banner"><Sparkles size={16}/><span><b>Preview mode:</b> sample member details are shown. Add your Supabase keys to enable real member login and records.</span></div>}{content}<footer className="footer"><span>© {new Date().getFullYear()} {gymName}</span><span>Train with purpose <span className="footer-heart">✦</span></span></footer></main></div>
    {!session && <AuthPanel mode={authMode} setMode={setAuthMode} email={authEmail} setEmail={setAuthEmail} password={authPassword} setPassword={setAuthPassword} name={authName} setName={setAuthName} submit={submitAuth} busy={busy} notice={notice}/>}
    {showSplash && <div className="fitness-splash"><div className="splash-logo"><Dumbbell size={36}/></div><div className="splash-brand">FIGHT <span>2 FIT</span></div><div className="splash-sub">GYM MEMBER CLUB</div><div className="splash-loader"><span></span></div></div>}
  </div>;
}

function AuthPanel({mode,setMode,email,setEmail,password,setPassword,name,setName,submit,busy,notice}) {
  const [open,setOpen] = useState(false);
  return <div className="auth-floating"><button className="btn btn-outline" onClick={()=>setOpen(!open)}>{open?'Close demo login':'Member login / signup'} <ArrowRight size={15}/></button>{open && <div className="auth-card"><div className="eyebrow">MEMBER ACCOUNT</div><h3>{mode==='login'?'Welcome back':'Create your account'}</h3><p>{isSupabaseConfigured ? 'Use your registered member account. Member records must be provisioned by the gym.' : 'Preview mode: connect your own Supabase project in .env to enable real authentication. No account is created in preview mode.'}</p><form onSubmit={submit}>{mode==='signup' && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} required/></label>}<label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label>Password<input type="password" minLength="8" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button className="btn btn-primary full" disabled={busy}>{busy?'Please wait…':mode==='login'?'Log in':'Sign up'}</button></form><button className="text-btn auth-switch" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'New member? Create account':'Already registered? Log in'}</button>{notice && <p className="auth-notice">{notice}</p>}</div>}</div>;
}