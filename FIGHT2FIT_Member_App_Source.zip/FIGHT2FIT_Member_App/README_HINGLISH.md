# FIGHT 2 FIT GYM — Member App starter project

**Theme:** yellow + orange + white, charcoal accents  
**Scope:** member-facing app only  
**Stack:** React + Vite + Supabase + Capacitor (Android wrapper)  
**Membership packages:** 1 month ₹2,000; 2 months ₹3,500; 3 months ₹4,500; 6 months ₹8,000; 12 months ₹12,000  
**One-time admission fee:** ₹200, only at admission if not already paid

## Important: what this ZIP is
This is an editable source-code project, not a compiled APK. The APK you shared was used only as a reference for the general client-app concept. This project does not contain YDL proprietary source code or connect to YDL's backend. The included UI has a demo preview, and real member data requires your own Supabase setup.

The workout/diet screens currently show sample content. QR shown in preview is not a verified gym check-in credential. Payment UI does not take money or mark payments as paid. Push notifications need an additional delivery setup. These must be connected and tested before real members use the app.

## 1. What you need
- A computer with a currently supported Windows version (Windows 10/11 recommended) or macOS/Linux.
- Node.js LTS and npm: https://nodejs.org/
- A free Supabase account/project: https://supabase.com/
- For Android APK builds: Android Studio with Android SDK, and Java/JDK compatible with your installed Android Gradle Plugin.
- Optional: a domain/website you control.

> If your computer is still Windows 7, current Node.js/Android Studio versions may not install or work reliably. Use a supported computer or first test the web version from a modern browser. Do not pay for a builder before testing the workflow.

## 2. Run the preview
1. Extract this ZIP.
2. Open a terminal in the extracted `FIGHT2FIT_Member_App` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Leave Supabase keys empty for preview mode, or add your own project URL and anon/publishable key for backend setup.
6. Run `npm run dev`.
7. Open the local URL printed in terminal (typically `http://localhost:5173`).

With no Supabase keys, the UI runs in **preview mode** using sample member data. Login/signup will not create accounts.

## 3. Connect your own Supabase project
1. Create a NEW Supabase project owned by FIGHT 2 FIT GYM.
2. Open Supabase → SQL Editor and run `supabase/schema.sql`.
3. Copy the Project URL and anon/publishable key from Supabase project settings into `.env`:
   - `VITE_SUPABASE_URL=...`
   - `VITE_SUPABASE_ANON_KEY=...`
4. Restart the dev server after changing `.env`.
5. Configure Authentication → URL Configuration with your local website URL and your production domain.
6. Create a test user and a corresponding `members` row with that user's auth UUID. Profile creation for real members should be done via a trusted admin process.
7. Test with two different accounts and confirm each sees only their own records.

**Never put a Supabase `service_role` secret in `.env` used by this frontend, APK, or website.** The anon/publishable key is designed for client use only when row-level security is correctly configured. Review every RLS policy before adding real client data.

## 4. Set your real gym settings
Update `.env` values:
- `VITE_GYM_NAME`
- `VITE_GYM_ADDRESS`
- `VITE_GYM_PHONE`
- `VITE_GYM_INSTAGRAM`
- `VITE_GYM_WEBSITE`

Current address is a prefilled working value and must be confirmed before public launch. Do not add a private phone/email unless you want it displayed to members.

## 5. Connect to your website
### Recommended route: host the web app under your website
1. Run `npm run build`; the production files will be created in `dist/`.
2. Upload the contents of `dist/` to a subdomain or path you control, e.g. `members.YOUR-DOMAIN.com` or `YOUR-DOMAIN.com/members/`.
3. Configure HTTPS, SPA fallback to `index.html`, and the correct Supabase redirect URLs.
4. Test sign-in, refresh/navigation, logout, mobile layout and database access on the live domain.

Hosting requirements vary by provider. If deploying under a subpath, configure Vite's `base` setting to match that path before building.

### Android app and website should share the same backend
The Android build can use the same Supabase project and the same deployed frontend code. Do not create separate copies of member records. Configure allowed redirect URLs for both the website and Android auth flow.

## 6. Build Android project / APK
1. Install Node.js LTS and Android Studio.
2. In the project folder, run `npm install`.
3. Run `npx cap add android` once.
4. Run `npm run android:sync`.
5. Run `npm run android:open` to open the Android project in Android Studio.
6. In Android Studio, allow Gradle/SDK setup to finish, then use Build → Build APK(s) for a debug/test APK.
7. Install on your own test phone and verify all screens before using real member data.

For a distributable release APK, configure app signing in Android Studio. Keep signing keys private and backed up. The ZIP does not include a prebuilt APK because a build environment and project credentials are not available here.

## 7. Current screens
- Overview dashboard
- Membership dates, expiry status and package pricing
- Workout plan sample
- Diet plan sample
- Progress logs
- QR member pass preview
- Payment history
- Member profile and gym contact details
- Short fitness-themed branded splash/loading screen and responsive button transitions

## 8. Membership pricing in the UI
| Package | Price |
|---|---:|
| 1 month | ₹2,000 |
| 2 months | ₹3,500 |
| 3 months | ₹4,500 |
| 6 months | ₹8,000 |
| 12 months | ₹12,000 |
| Admission fee | ₹200 one-time at admission if not already paid |

The UI only displays prices and renewal request information. It does not accept payment, renew a package, or calculate a paid status by itself. These actions require a secure admin workflow/payment integration.

## 9. Before launch checklist
- [ ] Confirm gym address, phone, logo, and website URL.
- [ ] Create your own Supabase project and run schema.
- [ ] Configure authentication and email verification.
- [ ] Add a trusted member provisioning/admin workflow.
- [ ] Assign actual workout/diet plans per member.
- [ ] Implement verified attendance scanning server-side.
- [ ] Connect a payment gateway only if you need online payments.
- [ ] Configure expiry notifications using a scheduled server/edge function and approved notification provider.
- [ ] Test RLS with multiple member accounts.
- [ ] Add privacy policy, terms, support contact, and account deletion process before public release.
- [ ] Test the APK on Android devices and your live website.

## Support note
This is a practical starter codebase, not a fully audited commercial release. Real authentication, database policies, payment and notification workflows must be configured and tested before production use.
